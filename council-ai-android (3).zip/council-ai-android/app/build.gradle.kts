plugins {
    id("com.android.application")
}

// Each GitHub build gets a higher number, so the app can tell when an update exists.
val buildNumber = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()

android {
    namespace = "com.salil.councilai"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.salil.councilai"
        minSdk = 26
        targetSdk = 35
        versionCode = buildNumber
        versionName = "2.$buildNumber"
    }

    // Fixed signing key, so every new build installs over the old one (keeps chats and keys).
    signingConfigs {
        getByName("debug") {
            storeFile = file("council.keystore")
            storePassword = "android"
            keyAlias = "council"
            keyPassword = "android"
        }
    }

    buildFeatures {
        buildConfig = true
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.12.1")
}
