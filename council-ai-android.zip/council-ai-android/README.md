# Council AI — Android app

Asks several free AI models the same question, then merges their answers into one.

## Get the APK (free, no Android Studio needed)

1. Sign in at github.com and create a new **private** repository called `council-ai`.
2. On your Mac, unzip `council-ai-android.zip`. Press **Cmd + Shift + .** in Finder so the hidden `.github` folder shows.
3. In the new repo, click **uploading an existing file** and drag in *everything inside* the unzipped folder, including `.github`. Click **Commit changes**.
4. Open the **Actions** tab. A "Build APK" run starts automatically and takes about 3–5 minutes.
5. When it shows a green tick, open the run and download **CouncilAI-apk** under *Artifacts*. Unzip it to get `CouncilAI.apk`.
6. Send the APK to your phone, open it, and allow "Install unknown apps" when asked.

If the `.github` folder won't upload: in the repo click **Add file → Create new file**, name it
`.github/workflows/build-apk.yml`, and paste in the contents of that file from the zip.

## Updating the app

Edit `app/src/main/assets/index.html` in GitHub (or upload a new version). Every commit rebuilds the APK.
For phones to treat it as an update, also raise `versionCode` in `app/build.gradle.kts`.
